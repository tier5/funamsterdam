<div id="rezgo" class="wrp_list">

<div id="left_panel">
	<div class="breadcrumb"><h1 class="header">Booking Terms</h1></div>

	<div class="item">

		<?=$site->getTerms()?>
	
	</div>
		
</div>