<?php

namespace OpenCloud\Common\Exceptions;

class InstanceFlavorError extends \Exception {}
