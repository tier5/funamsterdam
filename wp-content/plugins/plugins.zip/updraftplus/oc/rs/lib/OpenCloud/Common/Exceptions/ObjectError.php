<?php

namespace OpenCloud\Common\Exceptions;

class ObjectError extends \Exception {}
