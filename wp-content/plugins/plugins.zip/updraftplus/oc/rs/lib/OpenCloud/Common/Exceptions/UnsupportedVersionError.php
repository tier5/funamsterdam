<?php

namespace OpenCloud\Common\Exceptions;

class UnsupportedVersionError extends \Exception {}
