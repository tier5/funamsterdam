<?php

namespace OpenCloud\Common\Exceptions;

class MisMatchedChecksumError extends \Exception {}
