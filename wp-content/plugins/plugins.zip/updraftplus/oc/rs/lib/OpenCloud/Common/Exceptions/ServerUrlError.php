<?php

namespace OpenCloud\Common\Exceptions;

class ServerUrlError extends \Exception {}
