<?php

namespace OpenCloud\Common\Exceptions;

class VolumeTypeError extends \Exception {}
