<?php

namespace OpenCloud\Common\Exceptions;

class UserListError extends \Exception {}
