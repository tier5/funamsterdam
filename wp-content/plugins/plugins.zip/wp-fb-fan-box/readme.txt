=== Facebook Fan Box Widget ===
Contributors: Agus Suhanto
Donate link: http://suhanto.net/wp-fb-fan-box-widget-wordpress/
Tags: facebook fan box, facebook, facebook fan box, facebook like
Requires at least: 2.8
Tested up to: 3.0
Stable tag: 1.0

This is a WordPress widget to display a Facebook fan box on the sidebar. Utilizing Facebook fan box API, this widget displays the fans of your Facebook profile page.

== Description ==

This is a WordPress widget to display a Facebook fan box on the sidebar. Utilizing Facebook fan box API, this widget displays the fans of your Facebook profile page. This widget is easy to install because it is packaged as WordPress plugin that can be installed very quickly. It is also easy to use and configure because it is deployed as widget. The Facebook fan box also has 'Like' button. This button interacts with your blog readers directly, so if it is clicked, it will add up to the number of your fans.

This widget requires WordPress version 2.8 or above to function properly. It also requires you to have a Facebook profile page to be connected to. To create a Facebook profile page, you have to have an account in Facebook. This is easy to do, you can navigate to Facebook website and get started right away.

= Widget =

In the Appearance -> Widgets in WordPress 2.8 or newer you'll find the Facebook Fan Box widget. After adding it to your sidebar you can enter a title for the Widget, and all settings required for this widget to work properly.

== Installation ==

= Install =

1. Upload the 'wp-fb-fan-box' folder  to the '/wp-content/plugins/' directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to Appearance -> Widget -> Facebook Fan Box, drag and drop it to sidebar area, and start entering your info.

= Uninstall =

1. Deactivate Facebook Fan Box in the 'Plugins' menu in Wordpress.
2. After Deactivation a 'Delete' link appears below the plugin name, follow the link and confim with 'Yes, Delete these files'.
3. This will delete all the plugin files from the server as well as erasing all options the plugin has stored in the database.

== Frequently Asked Questions ==

Please visit [Facebook Fan Box Widget' Comments](http://suhanto.net/wp-fb-fan-box-widget-wordpress/#comments) for questions and answers.

== Screenshots ==

1. Widget appearance
2. Sidebar Widget Admin Options

== Changelog ==

= Version 1.0 - 26 June 2009 =
 * Initial Release