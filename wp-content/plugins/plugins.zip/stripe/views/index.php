<?php // Silence is golden 
